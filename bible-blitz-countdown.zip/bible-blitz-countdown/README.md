# ⚡ Bible Blitz Countdown

A daily 2-minute Bible trivia sprint — the same questions for every player worldwide, resetting at 12pm CST.

## Features

- **2-minute countdown** — answer as many multiple-choice questions as possible
- **4 difficulty tiers** with non-round point values:
  - 🟢 Easy — 100 pts
  - 🟡 Medium — 250 pts
  - 🟠 Hard — 500 pts
  - 🔴 Expert — 1,000 pts
- **Same daily questions worldwide** — seeded by date, resets at 12pm CST
- **No repeated questions for 60+ days** — large question bank with daily rotation
- **Shareable score card** — emoji grid like Wordle/MapTap
- **Leaderboard** — 30-day points, 90-day points, and continuous day streak
- **Multiple Bible translations** — NIV, KJV, ESV questions

## Tech Stack

- React 18 + Vite
- Pure CSS (no UI libraries)
- localStorage for scores and leaderboard

## Getting Started

```bash
npm install
npm run dev
```

## Build & Deploy

```bash
npm run build
# Deploy /dist folder to Vercel, Netlify, or any static host
```

### Vercel Deployment
1. Push to GitHub
2. Import repo in Vercel
3. Framework: Vite
4. Build command: `npm run build`
5. Output dir: `dist`

## Adding Questions

Edit `src/data/questions.js` — add to the `ALL_QUESTIONS` array with the schema:

```js
{
  id: "unique_id",
  difficulty: "easy" | "medium" | "hard" | "expert",
  points: 100 | 250 | 500 | 1000,
  translation: "NIV" | "KJV" | "ESV",
  question: "...",
  options: ["A", "B", "C", "D"],
  answer: "exact match to one option",
  reference: "Book Chapter:Verse"
}
```

## Architecture Notes

- **Day key**: Computed from current UTC time offset to CST (-6h). Before 12pm CST, uses previous day's key.
- **Question selection**: Each difficulty pool is shuffled with a date-based deterministic seed, then the first N are selected. This guarantees everyone worldwide gets the same set.
- **Leaderboard**: Stored in localStorage per device. For a global leaderboard, replace the localStorage calls in `src/utils/storage.js` with API calls to a backend (Supabase, Firebase, etc.).
- **Streak**: Calculated by checking whether consecutive days in `dailyScores` are contiguous.

## Roadmap

- [ ] Backend/global leaderboard (Supabase)
- [ ] Push notifications for daily reminder
- [ ] Admin question editor
- [ ] Themed weeks (Gospels, Prophecy, Epistles…)
- [ ] Bible Blitz branding tie-in

---

*Bible Blitz Countdown is part of the Bible Blitz family.*
