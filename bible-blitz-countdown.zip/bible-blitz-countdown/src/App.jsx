import React, { useState, useEffect } from 'react'
import { getDailyQuestions, getDayKey, getNextResetTime } from './data/questions.js'
import { getPlayer, getTodayResult, createPlayer } from './utils/storage.js'
import HomeScreen from './components/HomeScreen.jsx'
import GameScreen from './components/GameScreen.jsx'
import ResultScreen from './components/ResultScreen.jsx'
import LeaderboardScreen from './components/LeaderboardScreen.jsx'

// SCREENS: home | register | game | result | leaderboard
export default function App() {
  const [screen, setScreen] = useState('home')
  const [player, setPlayer] = useState(null)
  const [todayResult, setTodayResult] = useState(null)
  const [questions, setQuestions] = useState([])

  useEffect(() => {
    const p = getPlayer()
    setPlayer(p)
    const r = getTodayResult()
    setTodayResult(r)
    setQuestions(getDailyQuestions())
  }, [])

  function handleRegister(name) {
    const p = createPlayer(name)
    setPlayer(p)
    setScreen('game')
  }

  function handlePlayClick() {
    if (!player) {
      setScreen('register')
    } else if (todayResult) {
      setScreen('result')
    } else {
      setScreen('game')
    }
  }

  function handleGameComplete(result) {
    setTodayResult(result)
    setScreen('result')
  }

  return (
    <div className="app">
      {screen === 'home' && (
        <HomeScreen
          player={player}
          todayResult={todayResult}
          onPlay={handlePlayClick}
          onLeaderboard={() => setScreen('leaderboard')}
        />
      )}
      {screen === 'register' && (
        <RegisterScreen onRegister={handleRegister} onBack={() => setScreen('home')} />
      )}
      {screen === 'game' && (
        <GameScreen
          questions={questions}
          onComplete={handleGameComplete}
        />
      )}
      {screen === 'result' && (
        <ResultScreen
          result={todayResult}
          player={player}
          onHome={() => setScreen('home')}
          onLeaderboard={() => setScreen('leaderboard')}
        />
      )}
      {screen === 'leaderboard' && (
        <LeaderboardScreen
          player={player}
          onBack={() => setScreen('home')}
        />
      )}
    </div>
  )
}

function RegisterScreen({ onRegister, onBack }) {
  const [name, setName] = useState('')
  const [error, setError] = useState('')

  function handleSubmit() {
    const trimmed = name.trim()
    if (!trimmed) { setError('Please enter a name.'); return }
    if (trimmed.length < 2) { setError('Name must be at least 2 characters.'); return }
    onRegister(trimmed)
  }

  return (
    <div className="screen register-screen">
      <div className="register-card">
        <div className="register-icon">⚡</div>
        <h2 className="register-title">Enter Your Name</h2>
        <p className="register-sub">Your name will appear on the leaderboard</p>
        <input
          className="name-input"
          type="text"
          maxLength={20}
          placeholder="Your name…"
          value={name}
          onChange={e => { setName(e.target.value); setError('') }}
          onKeyDown={e => e.key === 'Enter' && handleSubmit()}
          autoFocus
        />
        {error && <p className="input-error">{error}</p>}
        <button className="btn btn-primary btn-lg" onClick={handleSubmit}>
          Start Playing →
        </button>
        <button className="btn btn-ghost" onClick={onBack}>← Back</button>
      </div>
    </div>
  )
}
