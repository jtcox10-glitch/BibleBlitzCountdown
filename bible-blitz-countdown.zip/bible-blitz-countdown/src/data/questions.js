// Bible Blitz Countdown - Question Bank
// Difficulty: easy (100pts), medium (250pts), hard (500pts), expert (1000pts)
// Multiple translations referenced

export const ALL_QUESTIONS = [
  // ── EASY (100 pts) ──────────────────────────────────────────────────────────
  {
    id: "e001",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "How many days did God take to create the world?",
    options: ["5", "6", "7", "8"],
    answer: "6",
    reference: "Genesis 1"
  },
  {
    id: "e002",
    difficulty: "easy",
    points: 100,
    translation: "KJV",
    question: "Who built the ark?",
    options: ["Moses", "Abraham", "Noah", "David"],
    answer: "Noah",
    reference: "Genesis 6"
  },
  {
    id: "e003",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "In what city was Jesus born?",
    options: ["Jerusalem", "Nazareth", "Bethlehem", "Jericho"],
    answer: "Bethlehem",
    reference: "Luke 2:4"
  },
  {
    id: "e004",
    difficulty: "easy",
    points: 100,
    translation: "ESV",
    question: "How many disciples did Jesus have?",
    options: ["10", "11", "12", "13"],
    answer: "12",
    reference: "Matthew 10:1"
  },
  {
    id: "e005",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "What is the shortest verse in the Bible?",
    options: ["God is love.", "Amen.", "Jesus wept.", "Be still."],
    answer: "Jesus wept.",
    reference: "John 11:35"
  },
  {
    id: "e006",
    difficulty: "easy",
    points: 100,
    translation: "KJV",
    question: "Who was swallowed by a great fish?",
    options: ["Elijah", "Jonah", "Isaiah", "Ezra"],
    answer: "Jonah",
    reference: "Jonah 1:17"
  },
  {
    id: "e007",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "What is the first book of the Bible?",
    options: ["Exodus", "Psalms", "Genesis", "Matthew"],
    answer: "Genesis",
    reference: "Genesis 1:1"
  },
  {
    id: "e008",
    difficulty: "easy",
    points: 100,
    translation: "ESV",
    question: "What did God create on the first day?",
    options: ["Animals", "Light", "Stars", "Man"],
    answer: "Light",
    reference: "Genesis 1:3"
  },
  {
    id: "e009",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "Who was the first man created by God?",
    options: ["Abraham", "Noah", "Adam", "Moses"],
    answer: "Adam",
    reference: "Genesis 2:7"
  },
  {
    id: "e010",
    difficulty: "easy",
    points: 100,
    translation: "KJV",
    question: "What fruit did Eve eat in the Garden of Eden?",
    options: ["Apple (forbidden fruit)", "Pomegranate", "Fig", "Grape"],
    answer: "Apple (forbidden fruit)",
    reference: "Genesis 3:6"
  },
  {
    id: "e011",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "Who parted the Red Sea?",
    options: ["Aaron", "Joshua", "Moses", "Elijah"],
    answer: "Moses",
    reference: "Exodus 14:21"
  },
  {
    id: "e012",
    difficulty: "easy",
    points: 100,
    translation: "ESV",
    question: "How many commandments did God give Moses?",
    options: ["5", "8", "10", "12"],
    answer: "10",
    reference: "Exodus 20"
  },
  {
    id: "e013",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "Who was Moses' sister?",
    options: ["Rachel", "Miriam", "Deborah", "Ruth"],
    answer: "Miriam",
    reference: "Exodus 15:20"
  },
  {
    id: "e014",
    difficulty: "easy",
    points: 100,
    translation: "KJV",
    question: "What is the last book of the Bible?",
    options: ["Jude", "Acts", "Hebrews", "Revelation"],
    answer: "Revelation",
    reference: "Revelation 22:21"
  },
  {
    id: "e015",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "Who was the mother of Jesus?",
    options: ["Martha", "Mary", "Elizabeth", "Sarah"],
    answer: "Mary",
    reference: "Luke 1:27"
  },
  {
    id: "e016",
    difficulty: "easy",
    points: 100,
    translation: "ESV",
    question: "Who baptized Jesus?",
    options: ["Peter", "Paul", "John the Baptist", "Andrew"],
    answer: "John the Baptist",
    reference: "Matthew 3:13-15"
  },
  {
    id: "e017",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "In what river was Jesus baptized?",
    options: ["Nile", "Euphrates", "Jordan", "Tigris"],
    answer: "Jordan",
    reference: "Matthew 3:13"
  },
  {
    id: "e018",
    difficulty: "easy",
    points: 100,
    translation: "KJV",
    question: "What did Jesus turn water into at the wedding in Cana?",
    options: ["Oil", "Milk", "Wine", "Honey"],
    answer: "Wine",
    reference: "John 2:9"
  },
  {
    id: "e019",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "How many days was Lazarus in the tomb before Jesus raised him?",
    options: ["1", "2", "3", "4"],
    answer: "4",
    reference: "John 11:17"
  },
  {
    id: "e020",
    difficulty: "easy",
    points: 100,
    translation: "ESV",
    question: "Who denied Jesus three times?",
    options: ["James", "John", "Peter", "Thomas"],
    answer: "Peter",
    reference: "Matthew 26:75"
  },
  {
    id: "e021",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "Who betrayed Jesus?",
    options: ["Judas Iscariot", "Pontius Pilate", "Herod", "Barabbas"],
    answer: "Judas Iscariot",
    reference: "Matthew 26:47-48"
  },
  {
    id: "e022",
    difficulty: "easy",
    points: 100,
    translation: "KJV",
    question: "How many loaves of bread did Jesus use to feed 5,000?",
    options: ["2", "5", "7", "12"],
    answer: "5",
    reference: "Matthew 14:17"
  },
  {
    id: "e023",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "On which day did Jesus rise from the dead?",
    options: ["First day", "Second day", "Third day", "Seventh day"],
    answer: "Third day",
    reference: "1 Corinthians 15:4"
  },
  {
    id: "e024",
    difficulty: "easy",
    points: 100,
    translation: "ESV",
    question: "What is the name of the garden where Jesus was arrested?",
    options: ["Eden", "Gethsemane", "Nazareth", "Bethany"],
    answer: "Gethsemane",
    reference: "Matthew 26:36"
  },
  {
    id: "e025",
    difficulty: "easy",
    points: 100,
    translation: "NIV",
    question: "What is the longest book in the Bible?",
    options: ["Isaiah", "Jeremiah", "Psalms", "Genesis"],
    answer: "Psalms",
    reference: "Psalm 1-150"
  },

  // ── MEDIUM (250 pts) ─────────────────────────────────────────────────────────
  {
    id: "m001",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "How many years did the Israelites wander in the wilderness?",
    options: ["20", "30", "40", "50"],
    answer: "40",
    reference: "Numbers 32:13"
  },
  {
    id: "m002",
    difficulty: "medium",
    points: 250,
    translation: "KJV",
    question: "What was the name of Abraham's first son?",
    options: ["Isaac", "Ishmael", "Jacob", "Esau"],
    answer: "Ishmael",
    reference: "Genesis 16:11"
  },
  {
    id: "m003",
    difficulty: "medium",
    points: 250,
    translation: "ESV",
    question: "How many pieces of silver was Joseph sold for by his brothers?",
    options: ["10", "20", "30", "40"],
    answer: "20",
    reference: "Genesis 37:28"
  },
  {
    id: "m004",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "Who was the first king of Israel?",
    options: ["David", "Solomon", "Saul", "Samuel"],
    answer: "Saul",
    reference: "1 Samuel 10:24"
  },
  {
    id: "m005",
    difficulty: "medium",
    points: 250,
    translation: "KJV",
    question: "How many books are in the New Testament?",
    options: ["25", "27", "29", "31"],
    answer: "27",
    reference: "New Testament"
  },
  {
    id: "m006",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "Who wrote most of the Psalms?",
    options: ["Moses", "Solomon", "David", "Asaph"],
    answer: "David",
    reference: "Psalms (titles)"
  },
  {
    id: "m007",
    difficulty: "medium",
    points: 250,
    translation: "ESV",
    question: "What is the name of Samson's Philistine wife who betrayed him?",
    options: ["Jezebel", "Bathsheba", "Delilah", "Rahab"],
    answer: "Delilah",
    reference: "Judges 16:4"
  },
  {
    id: "m008",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "Which prophet was taken to heaven in a chariot of fire?",
    options: ["Elisha", "Isaiah", "Elijah", "Ezekiel"],
    answer: "Elijah",
    reference: "2 Kings 2:11"
  },
  {
    id: "m009",
    difficulty: "medium",
    points: 250,
    translation: "KJV",
    question: "How many sons did Jacob have?",
    options: ["10", "11", "12", "13"],
    answer: "12",
    reference: "Genesis 35:22"
  },
  {
    id: "m010",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "What did the wise men (Magi) follow to find Jesus?",
    options: ["A cloud", "A star", "An angel", "A prophet"],
    answer: "A star",
    reference: "Matthew 2:2"
  },
  {
    id: "m011",
    difficulty: "medium",
    points: 250,
    translation: "ESV",
    question: "Who was the father of John the Baptist?",
    options: ["Joseph", "Zechariah", "Simeon", "Joachim"],
    answer: "Zechariah",
    reference: "Luke 1:13"
  },
  {
    id: "m012",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "What was the name of the hill where Jesus was crucified?",
    options: ["Mount Sinai", "Mount Zion", "Golgotha", "Mount Carmel"],
    answer: "Golgotha",
    reference: "John 19:17"
  },
  {
    id: "m013",
    difficulty: "medium",
    points: 250,
    translation: "KJV",
    question: "Who wrote the book of Acts?",
    options: ["Paul", "Luke", "Peter", "John"],
    answer: "Luke",
    reference: "Acts 1:1"
  },
  {
    id: "m014",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "How many fish were caught in the miraculous catch in John 21?",
    options: ["100", "153", "200", "300"],
    answer: "153",
    reference: "John 21:11"
  },
  {
    id: "m015",
    difficulty: "medium",
    points: 250,
    translation: "ESV",
    question: "What was the name of the high priest who condemned Jesus?",
    options: ["Annas", "Caiaphas", "Pilate", "Herod"],
    answer: "Caiaphas",
    reference: "Matthew 26:57"
  },
  {
    id: "m016",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "What was Paul's name before his conversion?",
    options: ["Barnabas", "Silas", "Saul", "Stephen"],
    answer: "Saul",
    reference: "Acts 9:1"
  },
  {
    id: "m017",
    difficulty: "medium",
    points: 250,
    translation: "KJV",
    question: "On what island was the apostle John when he wrote Revelation?",
    options: ["Crete", "Cyprus", "Malta", "Patmos"],
    answer: "Patmos",
    reference: "Revelation 1:9"
  },
  {
    id: "m018",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "Who was the first martyr of the Christian church?",
    options: ["James", "Peter", "Stephen", "Philip"],
    answer: "Stephen",
    reference: "Acts 7:59"
  },
  {
    id: "m019",
    difficulty: "medium",
    points: 250,
    translation: "ESV",
    question: "Which book of the Bible contains the Sermon on the Mount?",
    options: ["Mark", "Luke", "Matthew", "John"],
    answer: "Matthew",
    reference: "Matthew 5-7"
  },
  {
    id: "m020",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "What was the profession of Matthew before he followed Jesus?",
    options: ["Fisherman", "Carpenter", "Tax collector", "Shepherd"],
    answer: "Tax collector",
    reference: "Matthew 9:9"
  },
  {
    id: "m021",
    difficulty: "medium",
    points: 250,
    translation: "KJV",
    question: "How many plagues did God send on Egypt?",
    options: ["7", "8", "10", "12"],
    answer: "10",
    reference: "Exodus 7-12"
  },
  {
    id: "m022",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "Who was the commander of God's army that appeared to Joshua?",
    options: ["Gabriel", "Michael", "The commander of the Lord's army", "An elder"],
    answer: "The commander of the Lord's army",
    reference: "Joshua 5:14"
  },
  {
    id: "m023",
    difficulty: "medium",
    points: 250,
    translation: "ESV",
    question: "Who wrote the book of Proverbs primarily?",
    options: ["David", "Moses", "Solomon", "Ezra"],
    answer: "Solomon",
    reference: "Proverbs 1:1"
  },
  {
    id: "m024",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "What woman in the Old Testament was famous for her loyalty to her mother-in-law?",
    options: ["Esther", "Deborah", "Ruth", "Hannah"],
    answer: "Ruth",
    reference: "Ruth 1:16"
  },
  {
    id: "m025",
    difficulty: "medium",
    points: 250,
    translation: "KJV",
    question: "Which king had Daniel thrown into the lions' den?",
    options: ["Nebuchadnezzar", "Cyrus", "Darius", "Belshazzar"],
    answer: "Darius",
    reference: "Daniel 6:16"
  },
  {
    id: "m026",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "What was the name of Abraham's wife?",
    options: ["Rebekah", "Rachel", "Sarah", "Leah"],
    answer: "Sarah",
    reference: "Genesis 17:15"
  },
  {
    id: "m027",
    difficulty: "medium",
    points: 250,
    translation: "ESV",
    question: "Who helped Rahab and was spared when Jericho fell?",
    options: ["Rahab alone", "Rahab and her extended family", "Rahab and one son", "Rahab and her husband only"],
    answer: "Rahab and her extended family",
    reference: "Joshua 6:25"
  },
  {
    id: "m028",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "What did Gideon use to test the Lord's will?",
    options: ["A burning bush", "A fleece of wool", "A clay jar", "A staff"],
    answer: "A fleece of wool",
    reference: "Judges 6:37"
  },
  {
    id: "m029",
    difficulty: "medium",
    points: 250,
    translation: "KJV",
    question: "In the parable of the Prodigal Son, what did the father give the returning son?",
    options: ["A silver coin", "A robe, ring, and sandals", "Half his estate", "A fatted calf only"],
    answer: "A robe, ring, and sandals",
    reference: "Luke 15:22"
  },
  {
    id: "m030",
    difficulty: "medium",
    points: 250,
    translation: "NIV",
    question: "How many beatitudes are in Matthew chapter 5?",
    options: ["6", "7", "8", "9"],
    answer: "8",
    reference: "Matthew 5:3-10"
  },

  // ── HARD (500 pts) ───────────────────────────────────────────────────────────
  {
    id: "h001",
    difficulty: "hard",
    points: 500,
    translation: "ESV",
    question: "Who was Melchizedek?",
    options: ["A Philistine king", "King of Salem and priest of God Most High", "A Levitical high priest", "A Babylonian prophet"],
    answer: "King of Salem and priest of God Most High",
    reference: "Genesis 14:18"
  },
  {
    id: "h002",
    difficulty: "hard",
    points: 500,
    translation: "NIV",
    question: "How many years did Solomon reign over Israel?",
    options: ["20", "30", "40", "50"],
    answer: "40",
    reference: "1 Kings 11:42"
  },
  {
    id: "h003",
    difficulty: "hard",
    points: 500,
    translation: "KJV",
    question: "Which tribe of Israel was Paul from?",
    options: ["Judah", "Levi", "Benjamin", "Ephraim"],
    answer: "Benjamin",
    reference: "Philippians 3:5"
  },
  {
    id: "h004",
    difficulty: "hard",
    points: 500,
    translation: "ESV",
    question: "Who was the father of Methuselah?",
    options: ["Noah", "Lamech", "Enoch", "Jared"],
    answer: "Enoch",
    reference: "Genesis 5:21"
  },
  {
    id: "h005",
    difficulty: "hard",
    points: 500,
    translation: "NIV",
    question: "What is the Hebrew name for the first five books of Moses?",
    options: ["Septuagint", "Torah", "Talmud", "Midrash"],
    answer: "Torah",
    reference: "General Biblical knowledge"
  },
  {
    id: "h006",
    difficulty: "hard",
    points: 500,
    translation: "KJV",
    question: "Which prophet married a prostitute as commanded by God to illustrate Israel's unfaithfulness?",
    options: ["Amos", "Micah", "Hosea", "Joel"],
    answer: "Hosea",
    reference: "Hosea 1:2"
  },
  {
    id: "h007",
    difficulty: "hard",
    points: 500,
    translation: "ESV",
    question: "What was the name of Saul's daughter who loved David?",
    options: ["Merab", "Michal", "Tamar", "Abigail"],
    answer: "Michal",
    reference: "1 Samuel 18:20"
  },
  {
    id: "h008",
    difficulty: "hard",
    points: 500,
    translation: "NIV",
    question: "In Revelation, what is the number of the sealed from each tribe of Israel?",
    options: ["6,000", "10,000", "12,000", "144,000"],
    answer: "12,000",
    reference: "Revelation 7:5-8"
  },
  {
    id: "h009",
    difficulty: "hard",
    points: 500,
    translation: "KJV",
    question: "How old was Abraham when Isaac was born?",
    options: ["75", "90", "99", "100"],
    answer: "100",
    reference: "Genesis 21:5"
  },
  {
    id: "h010",
    difficulty: "hard",
    points: 500,
    translation: "ESV",
    question: "Who was Barnabas's cousin, mentioned in Colossians?",
    options: ["Timothy", "Titus", "Mark", "Luke"],
    answer: "Mark",
    reference: "Colossians 4:10"
  },
  {
    id: "h011",
    difficulty: "hard",
    points: 500,
    translation: "NIV",
    question: "What was the name of the valley where David killed Goliath?",
    options: ["Valley of Jehoshaphat", "Valley of Elah", "Valley of Hinnom", "Valley of Jezreel"],
    answer: "Valley of Elah",
    reference: "1 Samuel 17:2"
  },
  {
    id: "h012",
    difficulty: "hard",
    points: 500,
    translation: "KJV",
    question: "Which city's walls fell when the Israelites marched around it?",
    options: ["Ai", "Gibeon", "Jericho", "Hazor"],
    answer: "Jericho",
    reference: "Joshua 6:20"
  },
  {
    id: "h013",
    difficulty: "hard",
    points: 500,
    translation: "ESV",
    question: "Who replaced Judas Iscariot as an apostle?",
    options: ["Paul", "Barnabas", "Matthias", "Timothy"],
    answer: "Matthias",
    reference: "Acts 1:26"
  },
  {
    id: "h014",
    difficulty: "hard",
    points: 500,
    translation: "NIV",
    question: "In which book does the phrase 'the Lord is my shepherd' first appear?",
    options: ["Isaiah", "Psalms", "Ezekiel", "John"],
    answer: "Psalms",
    reference: "Psalm 23:1"
  },
  {
    id: "h015",
    difficulty: "hard",
    points: 500,
    translation: "KJV",
    question: "How many days and nights did Elijah travel to Horeb on the strength of angel-provided food?",
    options: ["20", "30", "40", "7"],
    answer: "40",
    reference: "1 Kings 19:8"
  },
  {
    id: "h016",
    difficulty: "hard",
    points: 500,
    translation: "ESV",
    question: "What does the name 'Immanuel' mean?",
    options: ["Son of God", "God with us", "God saves", "Praise God"],
    answer: "God with us",
    reference: "Matthew 1:23"
  },
  {
    id: "h017",
    difficulty: "hard",
    points: 500,
    translation: "NIV",
    question: "How many chapters are in the book of Psalms?",
    options: ["120", "140", "150", "160"],
    answer: "150",
    reference: "Psalms"
  },
  {
    id: "h018",
    difficulty: "hard",
    points: 500,
    translation: "KJV",
    question: "Which apostle asked Jesus to show him the Father?",
    options: ["Peter", "Thomas", "Philip", "Nathanael"],
    answer: "Philip",
    reference: "John 14:8"
  },
  {
    id: "h019",
    difficulty: "hard",
    points: 500,
    translation: "ESV",
    question: "What was the name of the man who helped Jesus carry the cross?",
    options: ["Simon of Jerusalem", "Simon the Zealot", "Simon of Cyrene", "Simon Peter"],
    answer: "Simon of Cyrene",
    reference: "Mark 15:21"
  },
  {
    id: "h020",
    difficulty: "hard",
    points: 500,
    translation: "NIV",
    question: "What was Lydia's occupation in Acts 16?",
    options: ["Tent maker", "Potter", "Seller of purple cloth", "Weaver"],
    answer: "Seller of purple cloth",
    reference: "Acts 16:14"
  },
  {
    id: "h021",
    difficulty: "hard",
    points: 500,
    translation: "KJV",
    question: "How many stones did David pick up to fight Goliath?",
    options: ["1", "3", "5", "7"],
    answer: "5",
    reference: "1 Samuel 17:40"
  },
  {
    id: "h022",
    difficulty: "hard",
    points: 500,
    translation: "ESV",
    question: "Which book of the Bible never mentions God directly?",
    options: ["Song of Solomon", "Esther", "Ruth", "Ecclesiastes"],
    answer: "Esther",
    reference: "Book of Esther"
  },
  {
    id: "h023",
    difficulty: "hard",
    points: 500,
    translation: "NIV",
    question: "In the Lord's Prayer, what comes after 'forgive us our debts'?",
    options: ["as we forgive our debtors", "for yours is the kingdom", "lead us not into temptation", "and deliver us from evil"],
    answer: "as we forgive our debtors",
    reference: "Matthew 6:12"
  },
  {
    id: "h024",
    difficulty: "hard",
    points: 500,
    translation: "KJV",
    question: "What was the occupation of Amos before he became a prophet?",
    options: ["Fisherman", "Priest", "Shepherd and fig grower", "Scribe"],
    answer: "Shepherd and fig grower",
    reference: "Amos 7:14"
  },
  {
    id: "h025",
    difficulty: "hard",
    points: 500,
    translation: "ESV",
    question: "What was the name of the first Gentile convert baptized by Peter?",
    options: ["Lydia", "Cornelius", "Sergius Paulus", "Crispus"],
    answer: "Cornelius",
    reference: "Acts 10:1,44-48"
  },

  // ── EXPERT (1000 pts) ────────────────────────────────────────────────────────
  {
    id: "x001",
    difficulty: "expert",
    points: 1000,
    translation: "ESV",
    question: "In Ezekiel's vision, how many faces did each living creature have?",
    options: ["1", "2", "4", "6"],
    answer: "4",
    reference: "Ezekiel 1:6"
  },
  {
    id: "x002",
    difficulty: "expert",
    points: 1000,
    translation: "NIV",
    question: "How many years did Methuselah live?",
    options: ["777", "850", "930", "969"],
    answer: "969",
    reference: "Genesis 5:27"
  },
  {
    id: "x003",
    difficulty: "expert",
    points: 1000,
    translation: "KJV",
    question: "Which of the seven churches in Revelation was called 'lukewarm'?",
    options: ["Sardis", "Philadelphia", "Laodicea", "Thyatira"],
    answer: "Laodicea",
    reference: "Revelation 3:16"
  },
  {
    id: "x004",
    difficulty: "expert",
    points: 1000,
    translation: "ESV",
    question: "What was the name of the bronze serpent Moses made in the wilderness?",
    options: ["Asherah", "Nehushtan", "Asherim", "Baal"],
    answer: "Nehushtan",
    reference: "2 Kings 18:4"
  },
  {
    id: "x005",
    difficulty: "expert",
    points: 1000,
    translation: "NIV",
    question: "Which chapter in the Bible is considered the center of the entire Bible by verse count?",
    options: ["Psalm 100", "Psalm 118", "Psalm 117", "Psalm 119"],
    answer: "Psalm 117",
    reference: "Psalm 117"
  },
  {
    id: "x006",
    difficulty: "expert",
    points: 1000,
    translation: "KJV",
    question: "In Numbers 22, what unusual thing happened to Balaam?",
    options: ["He flew to heaven", "His donkey spoke to him", "He was swallowed by the earth", "Fire consumed his offering"],
    answer: "His donkey spoke to him",
    reference: "Numbers 22:28"
  },
  {
    id: "x007",
    difficulty: "expert",
    points: 1000,
    translation: "ESV",
    question: "How many sons did Haman have in the book of Esther?",
    options: ["7", "8", "10", "12"],
    answer: "10",
    reference: "Esther 9:7-9"
  },
  {
    id: "x008",
    difficulty: "expert",
    points: 1000,
    translation: "NIV",
    question: "What is the Greek word used for 'church' in the New Testament?",
    options: ["Kurios", "Ekklesia", "Agape", "Pistis"],
    answer: "Ekklesia",
    reference: "Matthew 16:18"
  },
  {
    id: "x009",
    difficulty: "expert",
    points: 1000,
    translation: "KJV",
    question: "Who was Priscilla's husband?",
    options: ["Philip", "Apollos", "Aquila", "Silas"],
    answer: "Aquila",
    reference: "Acts 18:2"
  },
  {
    id: "x010",
    difficulty: "expert",
    points: 1000,
    translation: "ESV",
    question: "In the Tabernacle, what was kept in the Most Holy Place (Holy of Holies)?",
    options: ["The menorah", "The table of showbread", "The Ark of the Covenant", "The altar of incense"],
    answer: "The Ark of the Covenant",
    reference: "Exodus 26:34"
  },
  {
    id: "x011",
    difficulty: "expert",
    points: 1000,
    translation: "NIV",
    question: "How many of Jesus' parables are recorded only in the Gospel of Luke?",
    options: ["8", "12", "18", "22"],
    answer: "18",
    reference: "Luke (various)"
  },
  {
    id: "x012",
    difficulty: "expert",
    points: 1000,
    translation: "KJV",
    question: "What was the language of most of the Old Testament?",
    options: ["Aramaic", "Greek", "Latin", "Hebrew"],
    answer: "Hebrew",
    reference: "OT scholarship"
  },
  {
    id: "x013",
    difficulty: "expert",
    points: 1000,
    translation: "ESV",
    question: "Which judge of Israel made a rash vow that cost his daughter her life?",
    options: ["Gideon", "Samson", "Jephthah", "Deborah"],
    answer: "Jephthah",
    reference: "Judges 11:30-39"
  },
  {
    id: "x014",
    difficulty: "expert",
    points: 1000,
    translation: "NIV",
    question: "What was the name of the Roman governor before whom Paul appeared in Caesarea?",
    options: ["Gallio", "Festus", "Felix", "Agrippa"],
    answer: "Felix",
    reference: "Acts 24:1"
  },
  {
    id: "x015",
    difficulty: "expert",
    points: 1000,
    translation: "KJV",
    question: "In which Epistle does Paul list the fruit of the Spirit?",
    options: ["Romans", "Ephesians", "Galatians", "Colossians"],
    answer: "Galatians",
    reference: "Galatians 5:22"
  },
  {
    id: "x016",
    difficulty: "expert",
    points: 1000,
    translation: "ESV",
    question: "How many epistles (letters) did John write in the New Testament?",
    options: ["1", "2", "3", "4"],
    answer: "3",
    reference: "1-3 John"
  },
  {
    id: "x017",
    difficulty: "expert",
    points: 1000,
    translation: "NIV",
    question: "What does 'Selah' mean when found in the Psalms?",
    options: ["Praise God", "A musical pause or interlude", "Amen", "Forever"],
    answer: "A musical pause or interlude",
    reference: "Psalm 3:2 (various)"
  },
  {
    id: "x018",
    difficulty: "expert",
    points: 1000,
    translation: "KJV",
    question: "Who was the king of Israel when Elijah appeared on Mount Carmel?",
    options: ["Ahaz", "Jehoshaphat", "Ahab", "Joram"],
    answer: "Ahab",
    reference: "1 Kings 18:1"
  },
  {
    id: "x019",
    difficulty: "expert",
    points: 1000,
    translation: "ESV",
    question: "Which disciple is mentioned as the one Jesus loved (the Beloved Disciple)?",
    options: ["Peter", "James", "John", "Lazarus"],
    answer: "John",
    reference: "John 13:23"
  },
  {
    id: "x020",
    difficulty: "expert",
    points: 1000,
    translation: "NIV",
    question: "In the book of Job, how many friends came to comfort him?",
    options: ["2", "3", "4", "5"],
    answer: "3",
    reference: "Job 2:11"
  },
  {
    id: "x021",
    difficulty: "expert",
    points: 1000,
    translation: "KJV",
    question: "What is the longest chapter in the Bible?",
    options: ["Psalm 118", "Psalm 119", "Numbers 7", "Ezekiel 40"],
    answer: "Psalm 119",
    reference: "Psalm 119 (176 verses)"
  },
  {
    id: "x022",
    difficulty: "expert",
    points: 1000,
    translation: "ESV",
    question: "Who was the king of Babylon who saw the handwriting on the wall?",
    options: ["Nebuchadnezzar", "Darius", "Cyrus", "Belshazzar"],
    answer: "Belshazzar",
    reference: "Daniel 5:5"
  },
  {
    id: "x023",
    difficulty: "expert",
    points: 1000,
    translation: "NIV",
    question: "What does the name 'Bethlehem' mean?",
    options: ["House of God", "House of bread", "City of peace", "Tower of David"],
    answer: "House of bread",
    reference: "Hebrew etymology"
  },
  {
    id: "x024",
    difficulty: "expert",
    points: 1000,
    translation: "KJV",
    question: "How many books of the Bible did Paul write?",
    options: ["11", "12", "13", "14"],
    answer: "13",
    reference: "Pauline Epistles"
  },
  {
    id: "x025",
    difficulty: "expert",
    points: 1000,
    translation: "ESV",
    question: "In Exodus, what did the Israelites place on their doorposts for the Passover?",
    options: ["Olive oil", "Blood of a lamb", "Cedar wood", "Hyssop alone"],
    answer: "Blood of a lamb",
    reference: "Exodus 12:7"
  },
]

// Shuffle deterministically using a seed (date-based)
function seededRandom(seed) {
  let s = seed
  return function() {
    s = (s * 1664525 + 1013904223) & 0xffffffff
    return (s >>> 0) / 0xffffffff
  }
}

function shuffleWithSeed(arr, seed) {
  const rand = seededRandom(seed)
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

// Get the "day number" relative to a fixed epoch, resetting at 12pm CST
export function getDayKey() {
  // CST = UTC-6, CDT = UTC-5 (approximated as UTC-6 for simplicity)
  const now = new Date()
  const cstOffset = -6 * 60 // minutes
  const utcMs = now.getTime() + now.getTimezoneOffset() * 60000
  const cstMs = utcMs + cstOffset * 60000
  const cst = new Date(cstMs)
  
  // If before 12pm CST, use previous day's key
  const hour = cst.getHours()
  if (hour < 12) {
    cst.setDate(cst.getDate() - 1)
  }
  
  const y = cst.getFullYear()
  const m = String(cst.getMonth() + 1).padStart(2, '0')
  const d = String(cst.getDate()).padStart(2, '0')
  return `${y}-${m}-${d}`
}

export function getNextResetTime() {
  const now = new Date()
  const cstOffset = -6 * 60
  const utcMs = now.getTime() + now.getTimezoneOffset() * 60000
  const cstMs = utcMs + cstOffset * 60000
  const cst = new Date(cstMs)

  const nextReset = new Date(cst)
  if (cst.getHours() >= 12) {
    nextReset.setDate(nextReset.getDate() + 1)
  }
  nextReset.setHours(12, 0, 0, 0)

  // Convert back to local time
  const nextResetUtc = nextReset.getTime() - cstOffset * 60000
  return new Date(nextResetUtc - now.getTimezoneOffset() * 60000)
}

// Get today's 15 questions (3 easy, 5 medium, 5 hard, 2 expert)
export function getDailyQuestions() {
  const dayKey = getDayKey()
  // Create a numeric seed from the date
  const seed = dayKey.split('-').reduce((acc, n) => acc * 100 + parseInt(n), 0)

  const easy = ALL_QUESTIONS.filter(q => q.difficulty === 'easy')
  const medium = ALL_QUESTIONS.filter(q => q.difficulty === 'medium')
  const hard = ALL_QUESTIONS.filter(q => q.difficulty === 'hard')
  const expert = ALL_QUESTIONS.filter(q => q.difficulty === 'expert')

  const pickN = (arr, n, seedOffset) => shuffleWithSeed(arr, seed + seedOffset).slice(0, n)

  return [
    ...pickN(easy, 3, 1),
    ...pickN(medium, 5, 2),
    ...pickN(hard, 4, 3),
    ...pickN(expert, 3, 4),
  ]
}

export const DIFFICULTY_CONFIG = {
  easy:   { label: 'Easy',   points: 100,  color: '#4ade80', emoji: '🟢' },
  medium: { label: 'Medium', points: 250,  color: '#facc15', emoji: '🟡' },
  hard:   { label: 'Hard',   points: 500,  color: '#f97316', emoji: '🟠' },
  expert: { label: 'Expert', points: 1000, color: '#ef4444', emoji: '🔴' },
}
