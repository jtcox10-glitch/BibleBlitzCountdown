import { getDayKey } from '../data/questions.js'

const STORAGE_KEYS = {
  PLAYER: 'bbc_player',
  DAILY_RESULT: (day) => `bbc_result_${day}`,
  LEADERBOARD: 'bbc_leaderboard',
}

export function getPlayer() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.PLAYER)
    if (!raw) return null
    return JSON.parse(raw)
  } catch { return null }
}

export function savePlayer(player) {
  localStorage.setItem(STORAGE_KEYS.PLAYER, JSON.stringify(player))
}

export function createPlayer(name) {
  const player = {
    id: `${Date.now()}_${Math.random().toString(36).slice(2)}`,
    name: name.trim().slice(0, 20),
    createdAt: new Date().toISOString(),
  }
  savePlayer(player)
  return player
}

export function getTodayResult() {
  try {
    const dayKey = getDayKey()
    const raw = localStorage.getItem(STORAGE_KEYS.DAILY_RESULT(dayKey))
    if (!raw) return null
    return JSON.parse(raw)
  } catch { return null }
}

export function saveTodayResult(result) {
  const dayKey = getDayKey()
  const entry = { ...result, dayKey, savedAt: new Date().toISOString() }
  localStorage.setItem(STORAGE_KEYS.DAILY_RESULT(dayKey), JSON.stringify(entry))
  updateLeaderboard(entry)
  return entry
}

function updateLeaderboard(result) {
  const player = getPlayer()
  if (!player) return

  const lb = getLeaderboard()
  const existing = lb.find(e => e.playerId === player.id)

  const dayKey = result.dayKey
  const today = new Date(dayKey)

  if (existing) {
    // Update daily scores array (keep last 90 days)
    const dailyIndex = existing.dailyScores.findIndex(d => d.dayKey === dayKey)
    if (dailyIndex === -1) {
      existing.dailyScores.push({ dayKey, score: result.score, correct: result.correct })
    } else {
      // Allow updating if score improved
      if (result.score > existing.dailyScores[dailyIndex].score) {
        existing.dailyScores[dailyIndex] = { dayKey, score: result.score, correct: result.correct }
      }
    }

    // Keep only last 90 days
    existing.dailyScores = existing.dailyScores
      .sort((a, b) => b.dayKey.localeCompare(a.dayKey))
      .slice(0, 90)

    // Calculate streak
    existing.streak = calculateStreak(existing.dailyScores)
    existing.lastPlayed = dayKey
    existing.name = player.name // keep name up to date
  } else {
    lb.push({
      playerId: player.id,
      name: player.name,
      dailyScores: [{ dayKey, score: result.score, correct: result.correct }],
      streak: 1,
      lastPlayed: dayKey,
    })
  }

  localStorage.setItem(STORAGE_KEYS.LEADERBOARD, JSON.stringify(lb))
}

function calculateStreak(dailyScores) {
  if (!dailyScores.length) return 0
  const sorted = [...dailyScores].sort((a, b) => b.dayKey.localeCompare(a.dayKey))
  
  // Check if today or yesterday is included
  const today = getDayKey()
  const todayDate = new Date(today)
  const yesterday = new Date(todayDate)
  yesterday.setDate(yesterday.getDate() - 1)
  const yKey = yesterday.toISOString().slice(0, 10)

  if (sorted[0].dayKey !== today && sorted[0].dayKey !== yKey) return 0

  let streak = 1
  for (let i = 1; i < sorted.length; i++) {
    const prev = new Date(sorted[i - 1].dayKey)
    const curr = new Date(sorted[i].dayKey)
    const diff = Math.round((prev - curr) / (1000 * 60 * 60 * 24))
    if (diff === 1) {
      streak++
    } else {
      break
    }
  }
  return streak
}

export function getLeaderboard() {
  try {
    const raw = localStorage.getItem(STORAGE_KEYS.LEADERBOARD)
    if (!raw) return []
    return JSON.parse(raw)
  } catch { return [] }
}

export function getLeaderboardForPeriod(days) {
  const lb = getLeaderboard()
  const cutoffDate = new Date()
  cutoffDate.setDate(cutoffDate.getDate() - days)
  const cutoffKey = cutoffDate.toISOString().slice(0, 10)

  return lb
    .map(player => {
      const periodScores = player.dailyScores.filter(d => d.dayKey >= cutoffKey)
      const total = periodScores.reduce((sum, d) => sum + d.score, 0)
      const daysPlayed = periodScores.length
      return {
        playerId: player.playerId,
        name: player.name,
        total,
        daysPlayed,
        streak: player.streak,
        avgScore: daysPlayed > 0 ? Math.round(total / daysPlayed) : 0,
      }
    })
    .filter(p => p.total > 0)
    .sort((a, b) => b.total - a.total)
}

export function buildShareText(result, playerName) {
  const dayKey = getDayKey()
  const { score, correct, total, answerLog } = result
  const maxPossible = result.maxPossible || 0

  const emojiRow = answerLog.map(a => {
    if (!a.answered) return '⬛'
    if (a.correct) {
      if (a.difficulty === 'easy') return '🟢'
      if (a.difficulty === 'medium') return '🟡'
      if (a.difficulty === 'hard') return '🟠'
      return '🔴'
    }
    return '❌'
  }).join('')

  return `⚡ Bible Blitz Countdown ⚡
📅 ${dayKey}
✅ ${correct}/${total} correct
🏆 ${score.toLocaleString()} pts

${emojiRow}

Play at: bibleblitzcountdown.com`
}
